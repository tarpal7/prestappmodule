<?php
class PrestappV2ModuleConfig
{
    const BACKEND_URL = "https://e-commerceapp.es";
    const SYNC_TYPE = "henvio"; // realtime or henvio
    const SCHEMA_SHOP = "presta";
}