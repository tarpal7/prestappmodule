<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class PrestappDB
{
    function __construct() {
    }

    public static function createTable()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'prestapp_v2_hEnvio` (
            `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
            `action` varchar(255) NOT NULL,
            `item_name` varchar(255) NOT NULL,
            `item_id` varchar(255),
            `id_product` varchar(255),
            `idshopname` varchar(255) NOT NULL,
            `schemeshop` varchar(255) NOT NULL,
            `params` text,
            PRIMARY KEY (`id`),
            UNIQUE  `UNIQ` (  `id` )
            ) DEFAULT CHARSET=utf8';

        $result = Db::getInstance()->Execute($sql);
        return $result;
    }

    public static function deleteAllItems()
    {
        $sql = 'DELETE FROM `' . _DB_PREFIX_ . 'prestapp_v2_hEnvio`';

        $result = Db::getInstance()->Execute($sql);
        return $result;
    }

    public static function addItem($action, $item_name, $item_id = null, $id_product = null, $idshopname, $schemeshop, $params)
    {
        $sql = 'INSERT INTO  `' . _DB_PREFIX_ . 'prestapp_v2_hEnvio`(`action`, `item_name`, `item_id`, `id_product`, `idshopname`, `schemeshop`) VALUES('."'". $action ."',"."'". $item_name ."',"."'". $item_id ."',"."'". $id_product ."',"."'". $idshopname ."',"."'". $schemeshop ."'".');';

        $result = Db::getInstance()->Execute($sql);
        return $result;
    }

    public static function deleteItem($id)
    {
        $sql = "DELETE FROM `" . _DB_PREFIX_ . "prestapp_v2_hEnvio` WHERE id = ".$id.";";

        $result = Db::getInstance()->Execute($sql);
        return $result;
    }

    public static function getAllItems($limit, $offset)
    {
        $sql = "SELECT * FROM `" . _DB_PREFIX_ . "prestapp_v2_hEnvio` LIMIT ".$limit." OFFSET ".$offset.";";

        $result = Db::getInstance()->executeS($sql);
        return $result;
    }

    public static function arrayToText($params)
    {
        return json_encode($params);
    }
}