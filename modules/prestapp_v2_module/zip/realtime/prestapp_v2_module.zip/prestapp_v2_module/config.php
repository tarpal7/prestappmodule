<?php
class PrestappV2ModuleConfig
{
    const BACKEND_URL = "https://e-commerceapp.es";
    const SYNC_TYPE = "realtime"; // realtime or henvio
    const SCHEMA_SHOP = "presta";
}